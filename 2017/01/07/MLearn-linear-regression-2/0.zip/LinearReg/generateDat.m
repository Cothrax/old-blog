function [X,y]=generateDat(m,n,lim);
	theta=randn(n,1)*lim;
	X=rand(m,n)*lim;
	y=X*theta+randn(m,1)*(lim^2)+randn(1,1)*(lim^2);
