function theta=normalEqu(X,y);
	theta=pinv(X'*X)*X'*y;
