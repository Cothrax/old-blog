function linearReg();
	[X,y]=generateDat(1000,1,100);
	X=[ones(size(y),1) X];
	theta=gradientDes(X,y,1.5,2e2);
	disp([theta normalEqu(X,y)]);
	if size(X,2)==2
		param=[1 0;1 100];
		figure(2);
		plot(
			X(:,2),y,'om;(x,y);',
			param(:,2),param*theta,'b;h(x);'
			);
		xlabel('x');ylabel('y');title('linearReg');
		print -dpng 'Figure2.png';
	end;
