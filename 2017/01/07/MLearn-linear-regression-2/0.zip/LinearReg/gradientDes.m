function theta=gradientDes(X,y,alpha,iters);
	%feature scaling
	[m,n]=size(X);
	rag=max(X)-min(X);rag(1,1)=1;
	avg=sum(X)/size(X,1);avg(1,1)=0;
	X=(X.-avg)./rag;
	
	%gradient descent
	theta=zeros(n,1);
	his=zeros(iters,2);
	for k=1:iters
		tmp=X*theta-y;
		theta-=(X'*tmp)*alpha/m;
		his(k,:)=[(tmp'*tmp)/(2*m) theta(1)];
	end;
	
	%plot j(theta)
	figure(1);xlabel('iter');ylabel('y');
	plot(
		[1:iters],his(:,1),'b;J(theta);',
		[1:iters],his(:,2)*10000,'r;theta(1)*10000;'
		);
	print -dpng "Figure1.png";
	
	%theta calculation
	theta(1,1)-=(avg./rag)*theta;
	theta./=rag';
