function testc();
	x = [-10:0.1:10]; y = x;
	% compute f(x,y)
	Z = zeros(length(x), length(y));
	for i = 1:length(x)
		for j = 1:length(y)
			Z(j,i) = (x(i)-2)^2+3*(y(j)-2)^2;
		end;
	end;
	% draw f(x,y)
	contour(x,y,Z,[0:50:1000]);
	colorbar; grid('on');
	xlabel('x'); ylabel('y');
	print('-dpng','contour.png');
end;
